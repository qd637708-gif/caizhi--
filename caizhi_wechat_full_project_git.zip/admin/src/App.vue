<script setup>
import {ref,onMounted} from 'vue'
const API=__API_BASE__,token=ref(localStorage.getItem('caizhi_admin_token')||''),login=ref({username:'admin',password:'Admin@123456'}),tab=ref('dashboard')
const summary=ref({users:0,courses:0,questions:0,studyRecords:0}),courses=ref([]),questions=ref([]),users=ref([])
const newCourse=ref({title:'',description:'',category:'金融小白',difficulty:'初级',duration:10,knowledge_count:0,status:1,sort_order:0})
async function req(path,opt={}){const r=await fetch(API+path,{...opt,headers:{'Content-Type':'application/json',...(token.value?{Authorization:'Bearer '+token.value}:{}),...(opt.headers||{})}});const d=await r.json();if(!r.ok)throw Error(d.message||'请求失败');return d}
async function doLogin(){try{const d=await req('/admin/login',{method:'POST',body:JSON.stringify(login.value)});token.value=d.token;localStorage.setItem('caizhi_admin_token',token.value);load()}catch(e){alert(e.message)}}
async function load(){try{summary.value=await req('/admin/dashboard');courses.value=await req('/admin/courses');questions.value=await req('/admin/questions');users.value=(await req('/admin/users?size=20')).rows}catch(e){alert(e.message)}}
async function addCourse(){try{await req('/admin/courses',{method:'POST',body:JSON.stringify(newCourse.value)});newCourse.value={title:'',description:'',category:'金融小白',difficulty:'初级',duration:10,knowledge_count:0,status:1,sort_order:0};load()}catch(e){alert(e.message)}}
async function delCourse(id){if(confirm('确定删除课程？')){await req('/admin/courses/'+id,{method:'DELETE'});load()}}
function logout(){token.value='';localStorage.removeItem('caizhi_admin_token')}
onMounted(()=>{if(token.value)load()})
</script>
<template>
<div v-if="!token" class="login"><div class="login-card"><h1>财知学堂</h1><p>真实 API 管理后台</p><input v-model="login.username" placeholder="管理员账号"><input v-model="login.password" type="password" placeholder="密码"><button @click="doLogin">登录</button></div></div>
<div v-else class="layout"><aside><h2>财知学堂</h2><div v-for="x in [['dashboard','📊 数据概览'],['courses','📚 课程管理'],['questions','📝 题库管理'],['users','👥 用户数据']]" class="nav" :class="{on:tab===x[0]}" @click="tab=x[0]">{{x[1]}}</div><div class="nav logout" @click="logout">退出登录</div></aside>
<main><header><h1>{{tab==='dashboard'?'数据概览':tab==='courses'?'课程管理':tab==='questions'?'题库管理':'用户数据'}}</h1><span>V1.3 Launch Ready</span></header>
<section v-if="tab==='dashboard'"><div class="cards"><div class="stat"><b>{{summary.users}}</b><span>用户</span></div><div class="stat"><b>{{summary.courses}}</b><span>课程</span></div><div class="stat"><b>{{summary.questions}}</b><span>题目</span></div><div class="stat"><b>{{summary.studyRecords}}</b><span>学习记录</span></div></div><div class="panel"><h3>API 状态</h3><p>数据来自 MySQL，不再使用 Mock 数据。</p></div></section>
<section v-if="tab==='courses'"><div class="panel"><h3>新建课程</h3><div class="form"><input v-model="newCourse.title" placeholder="课程名称"><input v-model="newCourse.category" placeholder="分类"><input v-model="newCourse.duration" type="number" placeholder="时长"><textarea v-model="newCourse.description" placeholder="简介"></textarea><button @click="addCourse">创建</button></div></div><div class="panel"><h3>课程列表</h3><table><thead><tr><th>ID</th><th>课程</th><th>分类</th><th>难度</th><th>操作</th></tr></thead><tbody><tr v-for="c in courses" :key="c.id"><td>{{c.id}}</td><td>{{c.title}}</td><td>{{c.category}}</td><td>{{c.difficulty}}</td><td><button class="danger" @click="delCourse(c.id)">删除</button></td></tr></tbody></table></div></section>
<section v-if="tab==='questions'"><div class="panel"><h3>题库</h3><p>当前题目 {{questions.length}} 条。新增/编辑接口已经可用，下一步可增加可视化题目编辑器和批量导入。</p><table><thead><tr><th>ID</th><th>题目</th><th>知识点</th></tr></thead><tbody><tr v-for="q in questions" :key="q.id"><td>{{q.id}}</td><td>{{q.question}}</td><td>{{q.knowledge_point}}</td></tr></tbody></table></div></section>
<section v-if="tab==='users'"><div class="panel"><h3>用户</h3><table><thead><tr><th>ID</th><th>昵称</th><th>等级</th><th>经验</th><th>连续学习</th></tr></thead><tbody><tr v-for="u in users" :key="u.id"><td>{{u.id}}</td><td>{{u.nickname}}</td><td>{{u.level}}</td><td>{{u.experience}}</td><td>{{u.study_streak}}</td></tr></tbody></table></div></section>
</main></div>
</template>
