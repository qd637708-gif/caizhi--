# 财知学堂 Real API

Base URL:

`https://api.example.com/api`

## 用户认证

### POST /auth/wechat

生产请求：

```json
{"code":"wx.login()返回的code"}
```

开发请求：

```json
{"dev_openid":"local-user-001"}
```

返回：

```json
{
  "token":"JWT",
  "user":{"id":1,"nickname":"金融探索者","level":1}
}
```

后续：

`Authorization: Bearer JWT`

## 课程

### GET /courses
Query:
- `category`
- `q`

### GET /courses/:id
返回课程和 chapters。

### GET /chapters/:id
返回完整章节内容。

### GET /chapters/:id/questions
返回题目，但不返回正确答案。

## 学习

### GET /study/progress

### POST /study/progress

```json
{
  "course_id":1,
  "chapter_id":1,
  "progress":100,
  "is_finished":1,
  "study_seconds":240,
  "score":90
}
```

## 答题

### GET /quiz/questions?chapter_id=1&limit=10

服务端不会把 `answer` 返回给小程序。

### POST /quiz/submit

```json
{
  "chapter_id":1,
  "answers":[
    {"question_id":1,"answer":"A"},
    {"question_id":2,"answer":"C"}
  ]
}
```

返回成绩、正确数和解析。

## 模拟投资

### GET /portfolio

### POST /portfolio/orders

```json
{
  "stock_code":"A001",
  "stock_name":"示例公司",
  "side":"BUY",
  "quantity":100,
  "price":50
}
```

`side`: `BUY` / `SELL`

仅操作虚拟账户。

## 管理员

### POST /admin/login

```json
{"username":"admin","password":"Admin@123456"}
```

返回 admin JWT。

管理接口均需：

`Authorization: Bearer ADMIN_JWT`


## V1.3 新增

- `GET /api/wrong-questions` 用户错题
- `GET /api/badges` 用户徽章
- `GET /api/stats/overview` 用户学习概览
- `GET /api/health` 增加 MySQL 连通性检查

管理后台删除课程/章节/题目会写入 `audit_logs`。
