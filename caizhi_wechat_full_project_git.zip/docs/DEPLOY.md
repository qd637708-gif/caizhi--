# 财知学堂正式上线部署清单

## A. 云服务器

建议：
- Ubuntu 22.04/24.04
- 2C4G 起步用于 MVP
- Docker / Docker Compose
- Nginx
- 独立 MySQL 或云数据库

不要把 MySQL 3306 直接开放到公网。

## B. DNS / HTTPS

准备：
- `api.example.com` -> API 服务器
- `admin.example.com` -> 管理后台

使用可信 CA 签发 HTTPS 证书，并让 Nginx 终止 TLS。

## C. 微信小程序

在微信公众平台：
- 设置 AppID / AppSecret
- 设置 request 合法域名：`https://api.example.com`
- 配置隐私保护指引
- 配置用户协议/隐私政策
- 真机测试登录、课程、答题、模拟交易

## D. 服务端

生产 `.env` 至少配置：
- NODE_ENV=production
- DB_HOST / DB_PORT / DB_USER / DB_PASSWORD / DB_NAME
- JWT_SECRET
- WECHAT_APPID / WECHAT_APPSECRET
- CORS_ORIGIN
- ADMIN_USERNAME / ADMIN_PASSWORD

## E. 备份

至少：
- 每日 MySQL 全量备份
- 保留 7~30 天
- 每月至少做一次恢复演练

## F. 发布前验收

- 微信登录成功
- 新用户自动创建账户
- 课程列表/详情正常
- 学习进度持久化
- 答题评分由服务器计算
- 错题正确记录
- 收藏正常
- 虚拟账户买卖正常
- 管理员登录限流
- 管理员删除操作产生审计日志
- API 健康检查返回 db=up
- HTTPS、合法域名、隐私配置全部通过
