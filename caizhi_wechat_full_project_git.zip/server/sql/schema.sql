CREATE DATABASE IF NOT EXISTS caizhi DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE caizhi;

CREATE TABLE IF NOT EXISTS admin_users (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 username VARCHAR(50) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role VARCHAR(30) NOT NULL DEFAULT 'admin',
 status TINYINT NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 openid VARCHAR(64) NOT NULL UNIQUE,
 unionid VARCHAR(64),
 nickname VARCHAR(100) NOT NULL DEFAULT '金融探索者',
 avatar VARCHAR(500),
 level INT NOT NULL DEFAULT 1,
 experience INT NOT NULL DEFAULT 0,
 study_streak INT NOT NULL DEFAULT 0,
 last_study_date DATE NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_users_created(created_at)
);

CREATE TABLE IF NOT EXISTS courses (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 title VARCHAR(200) NOT NULL,
 description TEXT,
 cover VARCHAR(500),
 category VARCHAR(50) NOT NULL,
 difficulty VARCHAR(20) NOT NULL DEFAULT '初级',
 duration INT NOT NULL DEFAULT 10,
 knowledge_count INT NOT NULL DEFAULT 0,
 status TINYINT NOT NULL DEFAULT 1,
 sort_order INT NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_course_category(category),
 INDEX idx_course_status(status)
);

CREATE TABLE IF NOT EXISTS chapters (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 course_id BIGINT NOT NULL,
 title VARCHAR(200) NOT NULL,
 content LONGTEXT,
 type VARCHAR(30) NOT NULL DEFAULT 'article',
 duration INT NOT NULL DEFAULT 5,
 sort_order INT NOT NULL DEFAULT 0,
 status TINYINT NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE,
 INDEX idx_chapters_course(course_id)
);

CREATE TABLE IF NOT EXISTS questions (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 chapter_id BIGINT,
 type VARCHAR(30) NOT NULL DEFAULT 'single',
 difficulty INT NOT NULL DEFAULT 1,
 question TEXT NOT NULL,
 options JSON NOT NULL,
 answer VARCHAR(100) NOT NULL,
 explanation TEXT,
 knowledge_point VARCHAR(200),
 status TINYINT NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(chapter_id) REFERENCES chapters(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS study_records (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 user_id BIGINT NOT NULL,
 course_id BIGINT,
 chapter_id BIGINT,
 progress INT NOT NULL DEFAULT 0,
 is_finished TINYINT NOT NULL DEFAULT 0,
 score INT NOT NULL DEFAULT 0,
 study_seconds INT NOT NULL DEFAULT 0,
 last_studied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_user_chapter(user_id,chapter_id),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE SET NULL,
 FOREIGN KEY(chapter_id) REFERENCES chapters(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS quiz_attempts (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 user_id BIGINT NOT NULL,
 chapter_id BIGINT,
 total INT NOT NULL,
 correct INT NOT NULL,
 score INT NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(chapter_id) REFERENCES chapters(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS quiz_answers (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 attempt_id BIGINT NOT NULL,
 question_id BIGINT NOT NULL,
 selected_answer VARCHAR(100) NOT NULL,
 is_correct TINYINT NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(attempt_id) REFERENCES quiz_attempts(id) ON DELETE CASCADE,
 FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS favorites (
 user_id BIGINT NOT NULL,
 course_id BIGINT NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_id,course_id),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS wrong_questions (
 user_id BIGINT NOT NULL,
 question_id BIGINT NOT NULL,
 wrong_count INT NOT NULL DEFAULT 1,
 last_wrong_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_id,question_id),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS badges (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 name VARCHAR(100) NOT NULL,
 icon VARCHAR(500),
 description TEXT,
 condition_type VARCHAR(50),
 condition_value INT
);

CREATE TABLE IF NOT EXISTS user_badges (
 user_id BIGINT NOT NULL,
 badge_id BIGINT NOT NULL,
 awarded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_id,badge_id),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(badge_id) REFERENCES badges(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS virtual_accounts (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 user_id BIGINT NOT NULL UNIQUE,
 cash DECIMAL(18,2) NOT NULL DEFAULT 100000.00,
 total_assets DECIMAL(18,2) NOT NULL DEFAULT 100000.00,
 profit DECIMAL(18,2) NOT NULL DEFAULT 0,
 profit_rate DECIMAL(10,4) NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS positions (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 account_id BIGINT NOT NULL,
 stock_code VARCHAR(30) NOT NULL,
 stock_name VARCHAR(100) NOT NULL,
 quantity INT NOT NULL DEFAULT 0,
 avg_price DECIMAL(18,4) NOT NULL DEFAULT 0,
 market_price DECIMAL(18,4) NOT NULL DEFAULT 0,
 market_value DECIMAL(18,2) NOT NULL DEFAULT 0,
 profit DECIMAL(18,2) NOT NULL DEFAULT 0,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_account_stock(account_id,stock_code),
 FOREIGN KEY(account_id) REFERENCES virtual_accounts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS orders (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 account_id BIGINT NOT NULL,
 stock_code VARCHAR(30) NOT NULL,
 stock_name VARCHAR(100) NOT NULL,
 side ENUM('BUY','SELL') NOT NULL,
 quantity INT NOT NULL,
 price DECIMAL(18,4) NOT NULL,
 amount DECIMAL(18,2) NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(account_id) REFERENCES virtual_accounts(id) ON DELETE CASCADE
);

INSERT INTO courses(title,description,category,difficulty,duration,knowledge_count,status,sort_order)
SELECT '什么是钱？','理解货币的功能、起源与基本概念','金融小白','初级',12,10,1,1
WHERE NOT EXISTS(SELECT 1 FROM courses WHERE title='什么是钱？');

INSERT INTO courses(title,description,category,difficulty,duration,knowledge_count,status,sort_order)
SELECT '股票基础','股票、市值、PE、分红与风险','投资基础','初级',15,12,1,2
WHERE NOT EXISTS(SELECT 1 FROM courses WHERE title='股票基础');

INSERT INTO courses(title,description,category,difficulty,duration,knowledge_count,status,sort_order)
SELECT '基金入门','基金、ETF、净值和风险收益','投资基础','初级',12,10,1,3
WHERE NOT EXISTS(SELECT 1 FROM courses WHERE title='基金入门');

INSERT INTO chapters(course_id,title,content,type,duration,sort_order)
SELECT c.id,'钱的本质与功能','货币通常承担交易媒介、计价单位和价值储藏等功能。','article',4,1
FROM courses c WHERE c.title='什么是钱？'
AND NOT EXISTS(SELECT 1 FROM chapters ch WHERE ch.course_id=c.id);

INSERT INTO chapters(course_id,title,content,type,duration,sort_order)
SELECT c.id,'货币的起源与发展','从物物交换到商品货币、信用货币和电子支付。','article',4,2
FROM courses c WHERE c.title='什么是钱？'
AND (SELECT COUNT(*) FROM chapters ch WHERE ch.course_id=c.id)<2;

INSERT INTO chapters(course_id,title,content,type,duration,sort_order)
SELECT c.id,'货币的种类','现金、银行存款和不同支付工具的基本区别。','article',4,3
FROM courses c WHERE c.title='什么是钱？'
AND (SELECT COUNT(*) FROM chapters ch WHERE ch.course_id=c.id)<3;

INSERT INTO badges(name,icon,description,condition_type,condition_value)
SELECT '金融小白','📚','完成第一门课程','COURSE_FINISH',1
WHERE NOT EXISTS(SELECT 1 FROM badges WHERE name='金融小白');

INSERT INTO badges(name,icon,description,condition_type,condition_value)
SELECT '连续学习者','🔥','连续学习7天','STREAK',7
WHERE NOT EXISTS(SELECT 1 FROM badges WHERE name='连续学习者');


CREATE TABLE IF NOT EXISTS audit_logs (
 id BIGINT PRIMARY KEY AUTO_INCREMENT,
 admin_id BIGINT NULL,
 action VARCHAR(100) NOT NULL,
 resource_type VARCHAR(50),
 resource_id BIGINT NULL,
 detail JSON NULL,
 ip VARCHAR(64),
 user_agent VARCHAR(500),
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_audit_admin(admin_id),
 INDEX idx_audit_created(created_at),
 FOREIGN KEY(admin_id) REFERENCES admin_users(id) ON DELETE SET NULL
);

INSERT INTO questions(chapter_id,type,difficulty,question,options,answer,explanation,knowledge_point,status)
SELECT ch.id,'single',1,'货币最基本的功能之一是什么？',
       '[{"value":"A","label":"交易媒介"},{"value":"B","label":"增加税收"},{"value":"C","label":"决定天气"},{"value":"D","label":"消除所有风险"}]',
       'A','货币可以作为交易媒介，降低物物交换的成本。','货币的功能',1
FROM chapters ch
WHERE ch.title='钱的本质与功能'
AND NOT EXISTS(SELECT 1 FROM questions q WHERE q.question='货币最基本的功能之一是什么？');

INSERT INTO questions(chapter_id,type,difficulty,question,options,answer,explanation,knowledge_point,status)
SELECT ch.id,'single',1,'下面哪项最符合“计价单位”的含义？',
       '[{"value":"A","label":"用统一尺度表示商品价格"},{"value":"B","label":"保证资产永远上涨"},{"value":"C","label":"免除借款利息"},{"value":"D","label":"让所有交易免费"}]',
       'A','计价单位用于表示商品和服务的价格，便于比较价值。','货币的功能',1
FROM chapters ch
WHERE ch.title='钱的本质与功能'
AND NOT EXISTS(SELECT 1 FROM questions q WHERE q.question='下面哪项最符合“计价单位”的含义？');

INSERT INTO questions(chapter_id,type,difficulty,question,options,answer,explanation,knowledge_point,status)
SELECT ch.id,'single',1,'从物物交换走向货币交易，主要解决了什么问题？',
       '[{"value":"A","label":"需求必须同时匹配的问题"},{"value":"B","label":"所有价格上涨的问题"},{"value":"C","label":"企业融资的问题"},{"value":"D","label":"税率变化的问题"}]',
       'A','货币降低了物物交换中“双方恰好互相需要对方商品”的匹配难度。','货币起源',1
FROM chapters ch
WHERE ch.title='货币的起源与发展'
AND NOT EXISTS(SELECT 1 FROM questions q WHERE q.question='从物物交换走向货币交易，主要解决了什么问题？');
