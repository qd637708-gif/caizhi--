const env=require('../src/config');
const fs=require('fs');
const mysql=require('mysql2/promise');
const bcrypt=require('bcryptjs');

(async()=>{
 const conn=await mysql.createConnection({
   host:env.DB_HOST,port:env.DB_PORT,
   user:env.DB_USER,password:env.DB_PASSWORD,
   multipleStatements:true
 });
 const sql=fs.readFileSync(__dirname+'/../sql/schema.sql','utf8');
 await conn.query(sql);
 const hash=await bcrypt.hash(env.ADMIN_PASSWORD,12);
 await conn.query(
   `INSERT INTO ${env.DB_NAME}.admin_users(username,password_hash)
    VALUES(?,?) ON DUPLICATE KEY UPDATE password_hash=VALUES(password_hash)`,
   [env.ADMIN_USERNAME,hash]
 );
 console.log('Database initialized and admin account ready.');
 await conn.end();
})().catch(e=>{console.error(e);process.exit(1)});
