const express=require('express'),cors=require('cors'),helmet=require('helmet'),bcrypt=require('bcryptjs'),compression=require('compression'),rateLimit=require('express-rate-limit'),crypto=require('crypto'),pinoHttp=require('pino-http');
const {z}=require('zod');
const env=require('./config');
const db=require('./db'),{sign,requireUser,requireAdmin}=require('./auth'),{code2Session}=require('./wechat');
const app=express();
app.disable('x-powered-by');
app.use(pinoHttp({
  genReqId: (req) => req.headers['x-request-id'] || crypto.randomUUID()
}));
app.use(helmet());
const allowedOrigins = env.CORS_ORIGIN.split(',').map(x=>x.trim()).filter(Boolean);
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) return cb(null, true);
    return cb(new Error('CORS origin denied'));
  }
}));
app.use(compression());
app.use(express.json({limit:'2mb'}));
app.use(rateLimit({
  windowMs: env.RATE_LIMIT_WINDOW_MS,
  max: env.RATE_LIMIT_MAX,
  standardHeaders: true,
  legacyHeaders: false
}));

const loginLimiter = rateLimit({
  windowMs: env.RATE_LIMIT_WINDOW_MS,
  max: env.LOGIN_RATE_LIMIT_MAX,
  standardHeaders: true,
  legacyHeaders: false,
  message: {message:'登录请求过于频繁，请稍后再试'}
});

const idSchema = z.coerce.number().int().positive();

const ok=(res,data)=>res.json(data);
const bad=(res,msg,status=400)=>res.status(status).json({message:msg});
async function audit(req, action, resourceType, resourceId, detail={}) {
  try {
    await db.query(
      'INSERT INTO audit_logs(admin_id,action,resource_type,resource_id,detail,ip,user_agent) VALUES(?,?,?,?,?,?,?)',
      [req.user?.adminId || null, action, resourceType || null, resourceId || null, JSON.stringify(detail), req.ip, req.headers['user-agent'] || '']
    );
  } catch (e) {
    req.log?.warn({err:e}, 'audit log failed');
  }
}

app.get('/api/health',async(req,res)=>{
  try {
    await db.query('SELECT 1');
    ok(res,{ok:true,version:'1.3.0',db:'up',time:new Date().toISOString()});
  } catch (e) {
    ok(res,{ok:false,version:'1.3.0',db:'down',time:new Date().toISOString()});
  }
});

app.post('/api/auth/wechat',loginLimiter,async(req,res)=>{
 try{
  const {code,dev_openid}=req.body||{};
  if(code && typeof code!=='string') return bad(res,'登录参数错误',400);
  let wx;
  if(code) wx=await code2Session(code);
  else if(env.NODE_ENV!=='production' && dev_openid) wx={openid:dev_openid};
  else return bad(res,'缺少微信登录 code',400);
  const openid=wx.openid;
  const [rows]=await db.query('SELECT id,openid,unionid,nickname,avatar,level,experience,study_streak,last_study_date FROM users WHERE openid=?',[openid]);
  let user=rows[0];
  if(!user){
   const [r]=await db.query('INSERT INTO users(openid,unionid) VALUES(?,?)',[openid,wx.unionid||null]);
   await db.query('INSERT INTO virtual_accounts(user_id) VALUES(?)',[r.insertId]);
   const [u]=await db.query('SELECT id,openid,unionid,nickname,avatar,level,experience,study_streak,last_study_date FROM users WHERE id=?',[r.insertId]); user=u[0];
  }
  const token=sign({role:'user',userId:user.id,openid},{expiresIn:env.JWT_EXPIRES_IN});
  ok(res,{token,user});
 }catch(e){console.error(e);bad(res,e.message,500)}
});

app.post('/api/admin/login',loginLimiter,async(req,res)=>{
 try{
  const {username,password}=req.body||{};
  if(typeof username!=='string'||typeof password!=='string'||!username||!password) return bad(res,'账号或密码不能为空',400);
  const [rows]=await db.query('SELECT * FROM admin_users WHERE username=? AND status=1',[username]);
  if(!rows[0]||!(await bcrypt.compare(password||'',rows[0].password_hash))) return bad(res,'账号或密码错误',401);
  ok(res,{token:sign({role:'admin',adminId:rows[0].id,username:rows[0].username},{expiresIn:env.ADMIN_JWT_EXPIRES_IN})});
 }catch(e){bad(res,'登录失败',500)}
});

app.get('/api/me',requireUser,async(req,res)=>{
 const [rows]=await db.query('SELECT id,nickname,avatar,level,experience,study_streak,last_study_date,created_at FROM users WHERE id=?',[req.user.userId]);
 if(!rows[0])return bad(res,'用户不存在',404);ok(res,rows[0]);
});

app.get('/api/courses',async(req,res)=>{
 const {category,q}=req.query; let sql='SELECT * FROM courses WHERE status=1';const p=[];
 if(category){sql+=' AND category=?';p.push(category)} if(q){sql+=' AND (title LIKE ? OR description LIKE ?)';p.push('%'+q+'%','%'+q+'%')}
 sql+=' ORDER BY sort_order,id';const [rows]=await db.query(sql,p);ok(res,rows);
});
app.get('/api/courses/:id',async(req,res)=>{
 const parsedId=idSchema.safeParse(req.params.id); if(!parsedId.success)return bad(res,'ID 参数错误');
 const [c]=await db.query('SELECT * FROM courses WHERE id=? AND status=1',[req.params.id]);if(!c[0])return bad(res,'课程不存在',404);
 const [chapters]=await db.query('SELECT id,course_id,title,content,type,duration,sort_order,status FROM chapters WHERE course_id=? AND status=1 ORDER BY sort_order,id',[req.params.id]);
 ok(res,{...c[0],chapters});
});
app.get('/api/courses/:id/chapters',async(req,res)=>{
 const parsedId=idSchema.safeParse(req.params.id); if(!parsedId.success)return bad(res,'ID 参数错误');
 const [rows]=await db.query('SELECT id,course_id,title,content,type,duration,sort_order FROM chapters WHERE course_id=? AND status=1 ORDER BY sort_order,id',[req.params.id]);ok(res,rows);
});
app.get('/api/chapters/:id',async(req,res)=>{
 const parsedId=idSchema.safeParse(req.params.id); if(!parsedId.success)return bad(res,'ID 参数错误');
 const [rows]=await db.query('SELECT * FROM chapters WHERE id=? AND status=1',[req.params.id]);if(!rows[0])return bad(res,'章节不存在',404);
 ok(res,rows[0]);
});
app.get('/api/chapters/:id/questions',async(req,res)=>{
 const parsedId=idSchema.safeParse(req.params.id); if(!parsedId.success)return bad(res,'ID 参数错误');
 const [rows]=await db.query('SELECT id,type,difficulty,question,options,knowledge_point FROM questions WHERE chapter_id=? AND status=1 ORDER BY id',[req.params.id]);
 ok(res,rows.map(x=>({...x,options:typeof x.options==='string'?JSON.parse(x.options):x.options})));
});

app.get('/api/study/progress',requireUser,async(req,res)=>{
 const [rows]=await db.query(`SELECT sr.*,c.title course_title,ch.title chapter_title
 FROM study_records sr LEFT JOIN courses c ON c.id=sr.course_id LEFT JOIN chapters ch ON ch.id=sr.chapter_id
 WHERE sr.user_id=? ORDER BY sr.last_studied_at DESC`,[req.user.userId]);ok(res,rows);
});
app.post('/api/study/progress',requireUser,async(req,res)=>{
 const {course_id,chapter_id,progress=0,is_finished=0,score=0,study_seconds=0}=req.body||{};
 if(!course_id||!chapter_id)return bad(res,'course_id 和 chapter_id 必填');
 const conn=await db.getConnection();
 try{
  await conn.beginTransaction();
  await conn.query(`INSERT INTO study_records(user_id,course_id,chapter_id,progress,is_finished,score,study_seconds,last_studied_at)
   VALUES(?,?,?,?,?,?,?,NOW())
   ON DUPLICATE KEY UPDATE progress=VALUES(progress),is_finished=VALUES(is_finished),score=VALUES(score),study_seconds=study_seconds+VALUES(study_seconds),last_studied_at=NOW()`,
   [req.user.userId,course_id,chapter_id,Math.max(0,Math.min(100,progress)),is_finished?1:0,score,Math.max(0,study_seconds)]);
  const today=new Date().toISOString().slice(0,10);
  await conn.query(`UPDATE users SET experience=experience+?,level=FLOOR((experience+?)/500)+1,
   study_streak=IF(last_study_date=DATE_SUB(?,INTERVAL 1 DAY),study_streak+1,IF(last_study_date=?,study_streak,1)),last_study_date=? WHERE id=?`,
   [is_finished?20:5,is_finished?20:5,today,today,today,req.user.userId]);
  await conn.commit();ok(res,{ok:true});
 }catch(e){await conn.rollback();bad(res,e.message,500)}finally{conn.release()}
});

app.get('/api/quiz/questions',requireUser,async(req,res)=>{
 const {chapter_id,limit=10}=req.query;
 let sql='SELECT id,chapter_id,type,difficulty,question,options,knowledge_point FROM questions WHERE status=1';const p=[];
 if(chapter_id){sql+=' AND chapter_id=?';p.push(chapter_id)} sql+=' ORDER BY RAND() LIMIT '+Math.min(50,Math.max(1,Number(limit)));
 const [rows]=await db.query(sql,p);ok(res,rows.map(x=>({...x,options:typeof x.options==='string'?JSON.parse(x.options):x.options})));
});
app.post('/api/quiz/submit',requireUser,async(req,res)=>{
 const {chapter_id,answers}=req.body||{}; if(!Array.isArray(answers)||!answers.length)return bad(res,'answers 必须为数组');
 const ids=[...new Set(answers.map(x=>Number(x.question_id)).filter(Boolean))];if(!ids.length)return bad(res,'没有有效题目');
 const [qs]=await db.query(`SELECT id,answer,explanation,knowledge_point FROM questions WHERE id IN (${ids.map(()=>'?').join(',')})`,ids);
 const map=new Map(qs.map(x=>[x.id,x]));
 let correct=0; const result=[];
 for(const a of answers){const q=map.get(Number(a.question_id));if(!q)continue;const yes=String(a.answer)===String(q.answer);if(yes)correct++;result.push({question_id:q.id,selected_answer:a.answer,is_correct:yes,explanation:q.explanation,knowledge_point:q.knowledge_point});}
 const score=Math.round(correct/result.length*100);
 const conn=await db.getConnection();
 try{
  await conn.beginTransaction();
  const [r]=await conn.query('INSERT INTO quiz_attempts(user_id,chapter_id,total,correct,score) VALUES(?,?,?,?,?)',[req.user.userId,chapter_id||null,result.length,correct,score]);
  for(const x of result){
   await conn.query('INSERT INTO quiz_answers(attempt_id,question_id,selected_answer,is_correct) VALUES(?,?,?,?)',[r.insertId,x.question_id,x.selected_answer,x.is_correct?1:0]);
   if(!x.is_correct) await conn.query('INSERT INTO wrong_questions(user_id,question_id) VALUES(?,?) ON DUPLICATE KEY UPDATE wrong_count=wrong_count+1,last_wrong_at=NOW()',[req.user.userId,x.question_id]);
  }
  await conn.commit();ok(res,{attempt_id:r.insertId,total:result.length,correct,score,details:result});
 }catch(e){await conn.rollback();bad(res,e.message,500)}finally{conn.release()}
});

app.get('/api/favorites',requireUser,async(req,res)=>{
 const [rows]=await db.query(`SELECT c.* FROM favorites f JOIN courses c ON c.id=f.course_id WHERE f.user_id=? ORDER BY f.created_at DESC`,[req.user.userId]);ok(res,rows);
});
app.post('/api/favorites/:courseId',requireUser,async(req,res)=>{await db.query('INSERT IGNORE INTO favorites(user_id,course_id) VALUES(?,?)',[req.user.userId,req.params.courseId]);ok(res,{ok:true})});
app.delete('/api/favorites/:courseId',requireUser,async(req,res)=>{await db.query('DELETE FROM favorites WHERE user_id=? AND course_id=?',[req.user.userId,req.params.courseId]);ok(res,{ok:true})});

app.get('/api/portfolio',requireUser,async(req,res)=>{
 const [[account]]=await db.query('SELECT * FROM virtual_accounts WHERE user_id=?',[req.user.userId]);
 const [positions]=await db.query('SELECT * FROM positions WHERE account_id=? AND quantity>0',[account.id]);
 const [orders]=await db.query('SELECT * FROM orders WHERE account_id=? ORDER BY id DESC LIMIT 30',[account.id]);
 ok(res,{account,positions,orders});
});
app.get('/api/portfolio/orders',requireUser,async(req,res)=>{
 const [[a]]=await db.query('SELECT id FROM virtual_accounts WHERE user_id=?',[req.user.userId]);
 const [rows]=await db.query('SELECT * FROM orders WHERE account_id=? ORDER BY id DESC LIMIT 100',[a.id]);ok(res,rows);
});
app.post('/api/portfolio/orders',requireUser,async(req,res)=>{
 const {stock_code,stock_name,side,quantity,price}=req.body||{};
 const qty=Number(quantity),px=Number(price);if(!stock_code||!stock_name||!['BUY','SELL'].includes(side)||!Number.isInteger(qty)||qty<=0||!Number.isFinite(px)||px<=0)return bad(res,'订单参数错误');
 const conn=await db.getConnection();
 try{
  await conn.beginTransaction();
  const [[a]]=await conn.query('SELECT * FROM virtual_accounts WHERE user_id=? FOR UPDATE',[req.user.userId]);
  const amount=qty*px;const [ps]=await conn.query('SELECT * FROM positions WHERE account_id=? AND stock_code=? FOR UPDATE',[a.id,stock_code]);const p=ps[0];
  if(side==='BUY' && Number(a.cash)<amount)throw new Error('虚拟现金不足');
  if(side==='SELL' && (!p||p.quantity<qty))throw new Error('持仓不足');
  if(side==='BUY'){
   const newQty=(p?.quantity||0)+qty;const avg=((Number(p?.avg_price||0)*(p?.quantity||0))+amount)/newQty;
   await conn.query(`INSERT INTO positions(account_id,stock_code,stock_name,quantity,avg_price,market_price,market_value)
   VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE quantity=?,avg_price=?,market_price=?,market_value=?`,
   [a.id,stock_code,stock_name,newQty,avg,px,newQty*px,newQty,avg,px,newQty*px]);
   await conn.query('UPDATE virtual_accounts SET cash=cash-? WHERE id=?',[amount,a.id]);
  }else{
   const newQty=p.quantity-qty;await conn.query('UPDATE positions SET quantity=?,market_price=?,market_value=? WHERE id=?',[newQty,px,newQty*px,p.id]);
   await conn.query('UPDATE virtual_accounts SET cash=cash+? WHERE id=?',[amount,a.id]);
  }
  await conn.query('INSERT INTO orders(account_id,stock_code,stock_name,side,quantity,price,amount) VALUES(?,?,?,?,?,?,?)',[a.id,stock_code,stock_name,side,qty,px,amount]);
  await conn.commit();ok(res,{ok:true});
 }catch(e){await conn.rollback();bad(res,e.message)}finally{conn.release()}
});

app.get('/api/wrong-questions',requireUser,async(req,res)=>{
  const [rows]=await db.query(`
    SELECT w.question_id,w.wrong_count,w.last_wrong_at,q.question,q.options,q.explanation,q.knowledge_point
    FROM wrong_questions w JOIN questions q ON q.id=w.question_id
    WHERE w.user_id=? ORDER BY w.last_wrong_at DESC LIMIT 100
  `,[req.user.userId]);
  ok(res,rows.map(x=>({...x,options:typeof x.options==='string'?JSON.parse(x.options):x.options})));
});

app.get('/api/badges',requireUser,async(req,res)=>{
  const [rows]=await db.query(`
    SELECT b.*,ub.awarded_at
    FROM badges b LEFT JOIN user_badges ub ON ub.badge_id=b.id AND ub.user_id=?
    ORDER BY b.id
  `,[req.user.userId]);
  ok(res,rows);
});

app.get('/api/stats/overview',requireUser,async(req,res)=>{
  const [[study]]=await db.query('SELECT COUNT(*) count,COALESCE(SUM(study_seconds),0) seconds FROM study_records WHERE user_id=?',[req.user.userId]);
  const [[quiz]]=await db.query('SELECT COUNT(*) count,COALESCE(AVG(score),0) avg_score FROM quiz_attempts WHERE user_id=?',[req.user.userId]);
  const [[wrong]]=await db.query('SELECT COUNT(*) count FROM wrong_questions WHERE user_id=?',[req.user.userId]);
  ok(res,{studyRecords:Number(study.count),studySeconds:Number(study.seconds),quizAttempts:Number(quiz.count),averageScore:Number(quiz.avg_score||0),wrongQuestions:Number(wrong.count)});
});

app.get('/api/admin/dashboard',requireAdmin,async(req,res)=>{
 const [[users]]=await db.query('SELECT COUNT(*) count FROM users');const [[courses]]=await db.query('SELECT COUNT(*) count FROM courses');
 const [[questions]]=await db.query('SELECT COUNT(*) count FROM questions');const [[records]]=await db.query('SELECT COUNT(*) count FROM study_records');
 ok(res,{users:users.count,courses:courses.count,questions:questions.count,studyRecords:records.count});
});
app.get('/api/admin/users',requireAdmin,async(req,res)=>{
 const page=Math.max(1,Number(req.query.page||1)),size=Math.min(100,Math.max(1,Number(req.query.size||20))),offset=(page-1)*size;
 const [rows]=await db.query(`SELECT id,nickname,avatar,level,experience,study_streak,last_study_date,created_at FROM users ORDER BY id DESC LIMIT ? OFFSET ?`,[size,offset]);ok(res,{page,size,rows});
});
app.get('/api/admin/courses',requireAdmin,async(req,res)=>{const [rows]=await db.query('SELECT * FROM courses ORDER BY sort_order,id');ok(res,rows)});
app.post('/api/admin/courses',requireAdmin,async(req,res)=>{
 const {title,description='',cover='',category,difficulty='初级',duration=10,knowledge_count=0,status=1,sort_order=0}=req.body;
 if(!title||!category)return bad(res,'title 和 category 必填');
 const [r]=await db.query('INSERT INTO courses(title,description,cover,category,difficulty,duration,knowledge_count,status,sort_order) VALUES(?,?,?,?,?,?,?,?,?)',[title,description,cover,category,difficulty,duration,knowledge_count,status,sort_order]);ok(res,{id:r.insertId});
});
app.put('/api/admin/courses/:id',requireAdmin,async(req,res)=>{
 const {title,description='',cover='',category,difficulty='初级',duration=10,knowledge_count=0,status=1,sort_order=0}=req.body;
 await db.query('UPDATE courses SET title=?,description=?,cover=?,category=?,difficulty=?,duration=?,knowledge_count=?,status=?,sort_order=? WHERE id=?',[title,description,cover,category,difficulty,duration,knowledge_count,status,sort_order,req.params.id]);ok(res,{ok:true});
});
app.delete('/api/admin/courses/:id',requireAdmin,async(req,res)=>{await db.query('DELETE FROM courses WHERE id=?',[req.params.id]);await audit(req,'DELETE','course',Number(req.params.id));ok(res,{ok:true})});
app.post('/api/admin/courses/:id/chapters',requireAdmin,async(req,res)=>{
 const {title,content='',type='article',duration=5,sort_order=0,status=1}=req.body;
 const [r]=await db.query('INSERT INTO chapters(course_id,title,content,type,duration,sort_order,status) VALUES(?,?,?,?,?,?,?)',[req.params.id,title,content,type,duration,sort_order,status]);ok(res,{id:r.insertId});
});
app.put('/api/admin/chapters/:id',requireAdmin,async(req,res)=>{
 const {title,content='',type='article',duration=5,sort_order=0,status=1}=req.body;
 await db.query('UPDATE chapters SET title=?,content=?,type=?,duration=?,sort_order=?,status=? WHERE id=?',[title,content,type,duration,sort_order,status,req.params.id]);ok(res,{ok:true});
});
app.delete('/api/admin/chapters/:id',requireAdmin,async(req,res)=>{await db.query('DELETE FROM chapters WHERE id=?',[req.params.id]);await audit(req,'DELETE','chapter',Number(req.params.id));ok(res,{ok:true})});
app.get('/api/admin/questions',requireAdmin,async(req,res)=>{const [rows]=await db.query('SELECT * FROM questions ORDER BY id DESC');ok(res,rows.map(x=>({...x,options:typeof x.options==='string'?JSON.parse(x.options):x.options})))});
app.post('/api/admin/questions',requireAdmin,async(req,res)=>{
 const {chapter_id,type='single',difficulty=1,question,options,answer,explanation='',knowledge_point='',status=1}=req.body;
 if(!question||!answer)return bad(res,'question 和 answer 必填');
 const [r]=await db.query('INSERT INTO questions(chapter_id,type,difficulty,question,options,answer,explanation,knowledge_point,status) VALUES(?,?,?,?,?,?,?,?,?)',[chapter_id||null,type,difficulty,question,JSON.stringify(options||[]),answer,explanation,knowledge_point,status]);ok(res,{id:r.insertId});
});
app.put('/api/admin/questions/:id',requireAdmin,async(req,res)=>{
 const {chapter_id,type='single',difficulty=1,question,options,answer,explanation='',knowledge_point='',status=1}=req.body;
 await db.query('UPDATE questions SET chapter_id=?,type=?,difficulty=?,question=?,options=?,answer=?,explanation=?,knowledge_point=?,status=? WHERE id=?',[chapter_id||null,type,difficulty,question,JSON.stringify(options||[]),answer,explanation,knowledge_point,status,req.params.id]);ok(res,{ok:true});
});
app.delete('/api/admin/questions/:id',requireAdmin,async(req,res)=>{await db.query('DELETE FROM questions WHERE id=?',[req.params.id]);await audit(req,'DELETE','question',Number(req.params.id));ok(res,{ok:true})});

app.use((err,req,res,next)=>{
  req.log?.error({err}, 'request failed');
  const message = err?.message === 'CORS origin denied' ? '跨域来源不允许' : '服务器内部错误';
  res.status(err?.message === 'CORS origin denied' ? 403 : 500).json({message});
});

module.exports = app;
