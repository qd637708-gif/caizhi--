const dotenv = require('dotenv');
const { z } = require('zod');

dotenv.config();

const schema = z.object({
  NODE_ENV: z.enum(['development','test','production']).default('development'),
  PORT: z.coerce.number().int().positive().default(3000),
  DB_HOST: z.string().default('127.0.0.1'),
  DB_PORT: z.coerce.number().int().positive().default(3306),
  DB_USER: z.string().default('caizhi'),
  DB_PASSWORD: z.string().default(''),
  DB_NAME: z.string().default('caizhi'),
  JWT_SECRET: z.string().min(32, 'JWT_SECRET 至少 32 个字符'),
  JWT_EXPIRES_IN: z.string().default('7d'),
  ADMIN_JWT_EXPIRES_IN: z.string().default('8h'),
  WECHAT_APPID: z.string().default(''),
  WECHAT_APPSECRET: z.string().default(''),
  CORS_ORIGIN: z.string().default('*'),
  ADMIN_USERNAME: z.string().default('admin'),
  ADMIN_PASSWORD: z.string().min(8).default('Admin@123456'),
  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(60000),
  RATE_LIMIT_MAX: z.coerce.number().int().positive().default(120),
  LOGIN_RATE_LIMIT_MAX: z.coerce.number().int().positive().default(10)
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  console.error(parsed.error.flatten().fieldErrors);
  process.exit(1);
}
const env = parsed.data;

if (env.NODE_ENV === 'production') {
  if (!env.WECHAT_APPID || !env.WECHAT_APPSECRET) {
    throw new Error('生产环境必须配置 WECHAT_APPID / WECHAT_APPSECRET');
  }
  if (env.CORS_ORIGIN === '*') {
    throw new Error('生产环境必须将 CORS_ORIGIN 设置为明确的管理后台域名');
  }
  if (env.JWT_SECRET === 'replace_with_a_long_random_secret_at_least_32_chars') {
    throw new Error('生产环境必须修改 JWT_SECRET');
  }
}

module.exports = env;
