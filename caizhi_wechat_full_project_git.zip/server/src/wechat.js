const https=require('https');
const {WECHAT_APPID,WECHAT_APPSECRET}=require('./config');

function getJson(url){
 return new Promise((resolve,reject)=>{
   https.get(url,res=>{
     let data='';res.on('data',c=>data+=c);res.on('end',()=>{try{resolve(JSON.parse(data))}catch(e){reject(e)}})
   }).on('error',reject)
 })
}

async function code2Session(code){
 if(!WECHAT_APPID||!WECHAT_APPSECRET) throw new Error('WECHAT_APPID / WECHAT_APPSECRET 未配置');
 const url='https://api.weixin.qq.com/sns/jscode2session?appid='+encodeURIComponent(WECHAT_APPID)+'&secret='+encodeURIComponent(WECHAT_APPSECRET)+'&js_code='+encodeURIComponent(code)+'&grant_type=authorization_code';
 const data=await getJson(url);
 if(data.errcode) throw new Error(data.errmsg||'微信登录失败');
 return data;
}
module.exports={code2Session};
