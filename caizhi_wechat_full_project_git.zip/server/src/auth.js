const jwt = require('jsonwebtoken');
const env = require('./config');

function sign(payload, options = {}) {
  return jwt.sign(payload, env.JWT_SECRET, options);
}

function readToken(req) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : null;
}

function requireRole(role) {
  return (req, res, next) => {
    try {
      const token = readToken(req);
      if (!token) return res.status(401).json({message:'未登录'});
      const payload = jwt.verify(token, env.JWT_SECRET);
      if (payload.role !== role) return res.status(403).json({message:'无权限'});
      req.user = payload;
      next();
    } catch {
      return res.status(401).json({message:'登录已过期或无效'});
    }
  };
}

module.exports = {
  sign,
  requireUser: requireRole('user'),
  requireAdmin: requireRole('admin')
};
