const app = require('./app');
const env = require('./config');

app.listen(env.PORT, () => {
  console.log(`Caizhi Real API ${env.NODE_ENV} listening on ${env.PORT}`);
});
