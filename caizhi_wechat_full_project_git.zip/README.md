# 财知学堂 · 微信小程序完整项目

这是一个面向正式上线的微信小程序全栈项目，包含：

- `miniapp/`：微信小程序前端
- `server/`：Node.js + Express 真实 API 后端
- `admin/`：Vue 运营管理后台
- `nginx/`：API 反向代理示例
- `docs/`：API 与生产部署文档
- `docker-compose.yml`：本地/服务器部署基础配置

## 技术架构

微信小程序 → HTTPS/Nginx → Node.js API → MySQL 8

管理后台 → HTTPS/Nginx → Node.js API → MySQL 8

## 快速开始

### 1. 数据库

```bash
docker compose up -d mysql
```

### 2. API

```bash
cd server
cp .env.example .env
# 修改 .env
npm install
npm run db:init
npm run dev
```

默认 API：

`http://localhost:3000`

### 3. 管理后台

```bash
cd admin
npm install
npm run dev
```

默认：

`http://localhost:5173`

### 4. 微信小程序

使用微信开发者工具打开 `miniapp/`。

正式环境必须将：

`miniapp/app.js`

中的 API 地址改成 HTTPS 正式 API 域名，例如：

`https://api.example.com/api`

同时在微信公众平台配置 request 合法域名。

## 生产上线

详见：

`docs/DEPLOY.md`

## 安全

生产环境必须：

- 修改 JWT_SECRET
- 修改管理员密码
- 配置微信 AppID / AppSecret
- 使用 HTTPS
- 设置明确的 CORS_ORIGIN
- 不公开 MySQL 3306
- 配置数据库自动备份
- 配置日志与异常监控

## 当前业务边界

模拟投资模块仅用于金融教育模拟，不连接真实券商。

如果后续接入 A 股、港股、美股实时行情，需要接入合法行情数据服务，并由服务端统一校验行情价格。
