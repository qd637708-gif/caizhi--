const api=require('../../utils/api');
Page({
 data:{course:null,chapters:[]},
 async onLoad(o){try{const c=await api.course(o.id);this.setData({course:c,chapters:c.chapters||[]})}catch(e){wx.showToast({title:e.message||'加载失败',icon:'none'})}},
 async open(e){const id=e.currentTarget.dataset.id;wx.navigateTo({url:'/pages/quiz/index?chapterId='+id})}
})
