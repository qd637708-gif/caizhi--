const api=require('../../utils/api');
Page({
 data:{courses:[],category:'',q:''},
 async onLoad(){this.load()},
 async load(){try{this.setData({courses:await api.courses({category:this.data.category,q:this.data.q})})}catch(e){wx.showToast({title:e.message||'加载失败',icon:'none'})}},
 input(e){this.setData({q:e.detail.value})},
 search(){this.load()},
 go(e){wx.navigateTo({url:'/pages/course/detail?id='+e.currentTarget.dataset.id})}
})
