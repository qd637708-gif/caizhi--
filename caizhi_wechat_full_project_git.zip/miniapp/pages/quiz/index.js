const api=require('../../utils/api');
Page({
 data:{questions:[],index:0,answers:{},chapterId:''},
 async onLoad(o){this.setData({chapterId:o.chapterId||''});try{const q=await api.questions(o.chapterId,10);this.setData({questions:q})}catch(e){wx.showToast({title:e.message||'加载失败',icon:'none'})}},
 select(e){const answers={...this.data.answers,[e.currentTarget.dataset.q]:e.currentTarget.dataset.a};this.setData({answers})},
 async submit(){
  const answers=Object.keys(this.data.answers).map(question_id=>({question_id:Number(question_id),answer:this.data.answers[question_id]}));
  if(answers.length!==this.data.questions.length)return wx.showToast({title:'请完成所有题目',icon:'none'});
  try{const r=await api.submitQuiz({chapter_id:this.data.chapterId,answers});wx.redirectTo({url:'/pages/quiz/result?score='+r.score+'&correct='+r.correct+'&total='+r.total})}catch(e){wx.showToast({title:e.message||'提交失败',icon:'none'})}
 }
})
