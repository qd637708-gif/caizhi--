const api=require('../../utils/api');
Page({
 data:{user:null,courses:[],loading:true},
 async onShow(){
  try{
   if(!getApp().globalData.token) await api.login();
   const [courses,progress]=await Promise.all([api.courses(),api.progress()]);
   const map={};progress.forEach(x=>map[x.course_id]=x.progress);
   this.setData({user:getApp().globalData.user,courses:courses.slice(0,3).map(x=>({...x,progress:map[x.id]||0})),loading:false});
  }catch(e){console.error(e);this.setData({loading:false});wx.showToast({title:e.message||'网络错误',icon:'none'})}
 },
 goCourse(e){wx.navigateTo({url:'/pages/course/detail?id='+e.currentTarget.dataset.id})}
})
