const api=require('../../utils/api');
Page({data:{user:null},async onShow(){try{const u=await api.request('/me',{auth:true});this.setData({user:u})}catch(e){wx.showToast({title:'请重新登录',icon:'none'})}}})
