const api=require('../../utils/api');
Page({data:{account:null,positions:[]},async onShow(){try{const r=await api.portfolio();this.setData({account:r.account,positions:r.positions})}catch(e){wx.showToast({title:e.message||'加载失败',icon:'none'})}}})
