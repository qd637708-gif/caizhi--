App({
  globalData:{API_BASE_URL:'https://api.example.com/api',token:'',user:null},
  onLaunch(){
    const token=wx.getStorageSync('token'); if(token)this.globalData.token=token;
  }
})
